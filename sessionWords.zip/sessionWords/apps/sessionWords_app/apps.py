from django.apps import AppConfig


class SessionwordsAppConfig(AppConfig):
    name = 'sessionWords_app'
