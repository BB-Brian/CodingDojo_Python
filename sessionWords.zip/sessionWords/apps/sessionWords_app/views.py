from django.shortcuts import render, redirect, HttpResponse
from time import gmtime, strftime

def index(request):
    # return HttpResponse("yo yo yo yo")
    return render(request, 'sessionWords_app/index.html')

def process(request):
    if 'words' not in request.session:
        request.session['words'] = []

    if 'size' not in request.POST:
        size = 'small'
    else:
        size = request.POST['size']

    time = strftime("%I:%M:%S %p, %B %d %Y", gmtime())


    wordData = request.session['words']
    wordData.append({
        'word': request.POST['word'],
        'color': request.POST['color'],
        'size': size,
        'time': time
    })

    request.session['words'] = wordData

    return redirect('/')

def clear(request):
    request.session['words'] = []
    return redirect('/')
