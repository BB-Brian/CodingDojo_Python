from django.apps import AppConfig


class FriendsAppConfig(AppConfig):
    name = 'friends_app'
