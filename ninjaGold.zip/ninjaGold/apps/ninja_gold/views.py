from django.shortcuts import render, HttpResponse, redirect
import random
from time import gmtime, strftime
  # the index function is called when root is visited
def index(request):
    if 'gold' not in request.session:
        request.session['gold'] = 0
        request.session['activities'] = []
    return render(request, 'ninja_gold/index.html')

def process(request):
    place = request.POST['place']
    time = strftime("%Y/%m/%d %I:%M %p")
    color = 'green'

    if request.POST['place'] == 'farm':
        earned = random.randint(10,21)
        request.session['gold'] += earned
        activity = f"Earned {earned} golds from the {place}! ({time})"

    if request.POST['place'] == 'cave':
        earned = random.randint(5,11)
        request.session['gold'] += earned
        activity = f"Earned {earned} golds from the {place}! ({time})"

    if request.POST['place'] == 'house':
        earned = random.randint(2,5)
        request.session['gold'] += earned
        activity = f"Earned {earned} golds from the {place}! ({time})"

    if request.POST['place'] == 'casino':
        gain_loss = random.randint(1,2)
        earned = random.randint(0,50)

        if gain_loss == 2:
            request.session['gold'] -= earned
            activity = f"Entered a casino and lost {earned} golds... Ouch.. ({time})"
            color = 'red'
        else:
            request.session['gold'] += earned
            activity = f"Earned {earned} golds from the {request.POST['place']}! ({time})"


    request.session['activities'].append({
        'activity': activity,
        'color': color
    })
    return redirect('/')

def reset(request):
    request.session['gold'] = 0
    request.session['activities'] = []
    return redirect('/')
